<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Gudang extends Model
{
    use HasFactory;
    protected $table = 'gudangs';
    protected $fillable = [
        'nama',
        'status',
    ];

    protected $casts = [
        'status' => 'boolean', // Memastikan kolom status di-cast sebagai boolean
    ];

    // Timestamps otomatis diaktifkan (default true).
    public $timestamps = true;

    // Scope untuk memfilter gudang yang aktif.
    public function scopeActive($query)
    {
        return $query->where('status', true);
    }

    // Scope untuk memfilter gudang yang tidak aktif.
    public function scopeInactive($query)
    {
        return $query->where('status', false);
    }

        public function stocks(): HasMany
        {
            return $this->hasMany(Stock::class, 'gudang_id', 'id');
        }
    }
