<?php

namespace App\Filament\Resources\GudangResource\RelationManagers;

use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;

class StocksRelationManager extends RelationManager
{
    protected static string $relationship = 'stocks';

    public function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('barang_id')
                    ->label('ID Barang')
                    ->required()
                    ->numeric() // Pastikan input hanya angka
                    ->maxLength(255),

                Forms\Components\TextInput::make('balance')
                    ->label('Jumlah Stok')
                    ->required()
                    ->numeric() // Pastikan input hanya angka
                    ->minValue(0), // Tidak boleh negatif
            ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->recordTitleAttribute('barang_id')
            ->columns([
                Tables\Columns\TextColumn::make('barang.nama')
                    ->label('Nama Barang')
                    ->searchable()
                    ->sortable(),

                Tables\Columns\TextColumn::make('barang.satuan'),
                
                Tables\Columns\TextColumn::make('balance')
                    ->numeric()
                    ->sortable(),

                Tables\Columns\TextColumn::make('barang_id')
                    ->label('ID Barang')
                    ->searchable()
                    ->sortable(),

                Tables\Columns\TextColumn::make('created_at')
                    ->label('tanggal&waktu')
                    ->dateTime()
                    ->sortable(),

                Tables\Columns\TextColumn::make('gudang.status')
                    ->label('Status')
                    ->sortable(),
            ])
            ->filters([
                Tables\Filters\Filter::make('barang_nama')
                    ->query(fn (Builder $query, array $data) => $query->whereHas('barang', fn ($q) => $q->where('nama', 'like', "%{$data['value']}%")))
                    ->form([
                        Forms\Components\TextInput::make('value')
                            ->label('Cari Nama Barang'),
                    ]),
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make(),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }
}