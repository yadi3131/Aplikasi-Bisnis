<?php

use App\Filament\Resources\BarangResource;
use App\Models\Barang;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

use function pest\Livewire\livewire;

uses(RefreshDatabase::class);

beforeEach(function () {
    $this->actingAs(User::factory()->create());
});

describe('authenticated user using barang resource', function () {
    it ('can show index page', function(){
        $this->get(BarangResource::getUrl('index'))->assertSuccessful();
    });

    it('can access create page', function() {
        $this->get(BarangResource::getUrl('create'))->assertSuccessful();
    });
    it('can create barang', function(){
        $newData = Barang::factory()->make();
    
        Livewire(BarangResource\Pages\CreateBarang::class)
            ->fillForm([
                'nama' =>$newData->nama,
                'barcode' => $newData->barcode,
                'satuan' => $newData->satuan,
            ])
            ->call('create')
            ->assertHasNoFormErrors();
        
            $this->assertDatabaseHas(
                Barang::class,
                [
                'nama' => $newData->nama,
                'barcode' => $newData->barcode,
                'satuan' => $newData->satuan,
                'version' => $newData->version,
                ]
            );
    });
});