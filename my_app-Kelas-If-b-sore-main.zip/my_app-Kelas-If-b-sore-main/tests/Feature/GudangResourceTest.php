<?php

namespace Tests\Feature;

use App\Filament\Resources\GudangResource;
use App\Models\Gudang;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;

use function Pest\Livewire\livewire;

uses(RefreshDatabase::class);

beforeEach(function () {
    // Buat pengguna otentikasi
    $this->actingAs(User::factory()->create());
});

describe('authenticated user using gudang resource', function () {
    it('can show index page', function () {
        // Akses halaman indeks Gudang
        $this->get(GudangResource::getUrl('index'))
            ->assertSuccessful(); // Pastikan status kode 200 (OK)
    });

    it('can access create page', function () {
        // Akses halaman pembuatan Gudang
        $this->get(GudangResource::getUrl('create'))
            ->assertSuccessful(); // Pastikan status kode 200 (OK)
    });

    it('can create gudang', function () {
        // Buat data dummy Gudang menggunakan factory
        $newData = Gudang::factory()->make();

        // Gunakan Livewire untuk mengisi form dan membuat data Gudang
        livewire(\App\Filament\Resources\GudangResource\Pages\CreateGudang::class)
            ->fillForm([
                'nama' => $newData->nama,
                'status' => $newData->status,
            ])
            ->call('create') // Panggil metode "create" untuk menyimpan data
            ->assertHasNoFormErrors(); // Pastikan tidak ada error validasi

        // Pastikan data tersimpan di database
        $this->assertDatabaseHas(Gudang::class, [
            'nama' => $newData->nama,
            'status' => $newData->status,
        ]);
    });
});