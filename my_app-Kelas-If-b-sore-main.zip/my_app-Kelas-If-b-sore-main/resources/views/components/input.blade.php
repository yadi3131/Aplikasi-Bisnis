<input  {{ $attributes }}
    class="border border-blue-500 p-2 text-xl focus:bg-blue-100"/>
