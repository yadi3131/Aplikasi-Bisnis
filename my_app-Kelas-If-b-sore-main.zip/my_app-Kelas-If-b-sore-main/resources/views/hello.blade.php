<html>
<body>
    <h1>Hello {{ $nama }}</h1>
</body>
</html>